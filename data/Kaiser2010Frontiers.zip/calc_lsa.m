function [res,res2,res3]=calc_lsa(matrix,tr,MSIZE,krange,vrange)
% function [res,res2,res3]=calc_lsa(matrix,tr,MSIZE,krange,vrange);
%
% matrix: undirected adjacency matrix for testing
% tr: number of trials for each spreading parameter
% MSIZE size of localization of initial activity (default=N/10)
% krange: range of threshold parameter 
% vrange: range of deactivation parameter
% Author: Marcus Kaiser   Date: 23 March 2009

TIMESTEPS=200;
TRIALS=tr; 
res=zeros(length(krange),length(vrange));
r = zeros(2,1);
vstep = vrange(2)-vrange(1);
voffset = (vrange(1)/vstep)-1;
kstep = krange(2)-krange(1);
koffset = (krange(1)/kstep)-1;

for k=krange
    for v=vrange
        for t=1:TRIALS
            r(1) = 1+floor(rand(1)*MSIZE);
            r(2) = 1+floor(rand(1)*MSIZE);  
            i = min(r); % number of initially active columns
            i_0 = max(r); % localization of initial activation
            rho = calc_spreading(matrix,1,v,TIMESTEPS,k,i,i_0,TIMESTEPS,1);
            if (rho(TIMESTEPS)~=0) && (rho(TIMESTEPS)<0.5)
                ki = round((k/kstep)-koffset);
                vi = round((v/vstep)-voffset);
                res(ki,vi)= res(ki,vi) + 1; % sustained activity
            end; % if
        end; % t
    end; % v
end; % k
res2 = res / TRIALS; % was giving output 10/07/09
res = mean(mean(res2));
res3 = max(max(res2));
return;









function  [rho,halftime,avgdeg,evolution] = calc_spreading(mmatrix,nu,sigma,maxsteps,numb,init,initclu,TIMESTEPS,fast)
% [rho,halftime,avgdeg,evolution] = calc_spreading(mmatrix,nu,sigma,maxsteps,numb,init,initclu,TIMESTEPS,fast);
% Last modified by Matthias Goerner, Date: 26 April 2006
% introduced fast
% introduced TIMESTEPS
% introduced maxsteps
% replaced neighbours-function by matrix multiplication for drastic speed up 
% introduced numb and initclu
% was originally: outbreak by suspectible-infected-suspectible model
% Author: Marcus Kaiser   Date: 18 Jun 2004
% Input parameters:
% matrix: representing network
 % Simulation parameters:
% nu: activation probability
% signma: deactivation probability
% maxsteps: maximal number of timesteps a node can stay active
% numb: necessary number of neighbouring nodes being active
% Initialization parameters:    
% init: number of activated nodes
% initclu: localization parameter
% TIMESTEPS: number of timesteps
% fast: if set to 1, the simulation will stop once activation is more than 70%
% Output
% rho (array): fraction of activated nodes in i-th timestep
% when in fast mode, this is partially undefined
% but the last timestep is set to 1 is activity reached 70%
% halftime: first timestep than more than half was activated
% avgdeg: average relative degree of the infected nodes
% (normalized to average degree of all nodes)



halftime=-1;

n = length(mmatrix);
dl = sum(mmatrix)*2;%degrees(matrix);
AVGDEGALL = mean(dl); % average degree of all nodes

rho = zeros(TIMESTEPS,1);
avgdeg = zeros(TIMESTEPS,1);
evolution =zeros(n,TIMESTEPS,'uint8');
rho(1) = init/n;
infected = zeros(n,1,'uint8');
infectednew = zeros(n,1,'uint8');
newinfected = zeros(n,1,'uint8');
dummy = zeros(n,1,'uint8');
r = randperm(initclu);  
infected(r(1:init)) = uint8(maxsteps);  % init nodes are activated
evolution(:,1)=infected;

matrix=single(mmatrix);

for t=2:TIMESTEPS
    if rho(t-1)>0 
        newinfected = infected;
        dummy = single(infected>0);
        infectednew = matrix*dummy; 
        
        for i=1:n
            if infected(i) == 0  % node is not activated
              if infectednew(i) >= numb
                  if rand(1) <= nu         % activation occurring?
                      newinfected(i) = uint8(maxsteps);
                  end;
              end;
            else  % node is infected
                  if rand(1) <= sigma       % deactivation possible?
                      newinfected(i) = 0;
                  else
                      newinfected(i) = infected(i) - 1;  
                  end;
            end;        
        end;
        
        infected = newinfected;
        evolution(:,t)=infected; % new: 23 Nov 2007
        id = find(infected);
        if isempty(id)
            avgdeg(t) = 0;
        else
            avgdeg(t) = mean(dl(id)) / AVGDEGALL;
        end;
        rho(t) = sum(infected>0)/n;
        if (rho(t)>0.5) & (halftime==-1) 
            halftime=t;
        end;
        if fast
            if rho(t)>0.7
                rho(TIMESTEPS)=1;
                return
            end;
            if rho(t)==0
                rho(TIMESTEPS)=0;
                return
            end;
        end;
    else
      rho(t)=0;
    end;
end;

return


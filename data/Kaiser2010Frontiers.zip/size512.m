% size512
% tests different hierarchical
% configurations for a 512 node network
% Author: Marcus Kaiser
% Date: 25 Feb 2009

% hierarchical configurations
levels = 0:4; % hierarchical levels 
modules = 2:2:20; % modules within level 0
scales = 512; % number of columns in the 'rat'-like brain network
% remark: here only one network size is used. s can also be an array
%              of different sizes. In this case, the '1' in the three variables has to be 
%             replaced with the number of scales and the variable c determines
%             which element of the array scales is used for the following calculation 
res = zeros(1,length(levels),max(modules));
dres = zeros(1,length(levels),max(modules));
maxres = zeros(1,2);

% simulation parameters

% *************************      WARNING        *************************
% with the number of 200 trials and 50 networks given below, this routine
% will run 10 hours on an average processor! Please use smaller values for
% a first test.
% ***********************************************************************

trials = 200; 
networks = 50; 
krange = 1:2:9; % threshold parameter 
vrange = 0.1:0.2:0.9; % deactivation parameter

% calculate the LSA for the different hierarchical configurations
c=1;
s=scales(c);
datestr(now)
msize = round(s/10);
tic;
for l = levels
    for m = modules
        N = s;
        E = round(0.012 * N^2); % for constant edge density
                                              % alternatively, set E = 50 * N for constant node degree
        N_c = N / m^(l); % size of smallest cluster
        E_c = E / m^(l) / (l+1); % edges within smallest cluster
        if N_c^2 > E_c
            for nets = 1:networks
                clear d;
                [d,k] = hiergraph(N,E,l+1,m,1);                        
                res(c,l+1,m) = res(c,l+1,m) + calc_lsa(d,trials,msize,krange,vrange);
            end;
            res(c,l+1,m) = res(c,l+1,m) / networks;
            dres(c,l+1,m) = 1;
        end;
        fprintf('LSA value %f at level %d and %d sub-modules per module\n',res(c,l+1,m), l, m);
    end;
end;    
[dummy,i] = max(max(squeeze(res(c,:,:)),[],1)); 
[dummy,j] = max(max(squeeze(res(c,:,:)),[],2));
maxres(c,1:2) = [i j];
fprintf('Maximum at #levels = %i  and #modules/level = %i\n',i,j);
toc

% visualize results    
draw_figure(modules,levels,squeeze(res(1,levels+1,modules)),squeeze(dres(1,levels+1,modules)>0));
colormap(1-gray);
xlabel('Sub-modules per module');
ylabel('Hierarchical levels');
colorbar;
    

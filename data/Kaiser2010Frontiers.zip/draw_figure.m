function draw_figure(xlab,ylab,matrix,amatrix,maxx)
% function draw_figure(xlab,ylab,matrix,amatrix,maxx)
% draw figure of calculations and  mark 
% configurations which are not allowed 
% xlab: labels for the x-axis
% ylab: labels for the y-axis
% matrix: LSA values to be displayed
% amatrix: matrix of actually allowed calculations (1=allowed)
% maxx: (optional) maximum value used for the colour bar
%            this is used for scaling different plots to the same 
%           gray level scale; if no value is given, the maximum value
%           in the matris is used
% Author: Marcus Kaiser   Date: 30 March 2009

smatrix = matrix(amatrix);

% determine maximum value for graylevel scale
if isempty(who('maxx'))
    smin = min(min(smatrix));
    smax = max(max(smatrix));
else
    smin = 0;
    smax = maxx;
end;

% show LSA levels
imagesc(xlab,ylab,matrix.* amatrix,[smin smax]);

% mark unallowed configurations with a horizontal line
for x=1:length(xlab) 
    for y=1:length(ylab)
        if amatrix(y,x) == 0
           line([xlab(x)-1 xlab(x)+1],[ylab(y)-0.3333333 ylab(y)-0.3333333]);
           line([xlab(x)-1 xlab(x)+1],[ylab(y) ylab(y)]);
           line([xlab(x)-1 xlab(x)+1],[ylab(y)+0.3333333 ylab(y)+0.3333333]);
        end;
    end;
end;

% print minimum and maximum of the used scale
[smin smax]

